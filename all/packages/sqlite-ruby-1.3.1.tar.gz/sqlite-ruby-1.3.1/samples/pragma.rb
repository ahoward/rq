#!/usr/bin/ruby -Ilib

# --------------------------------------------------------------------------
# pragma.rb -- examples of the pragma features of SQLite
# Copyright (C) 2003 Jamis Buck (jgb3@email.byu.edu)
# --------------------------------------------------------------------------
# This file is part of the SQLite ruby interface.
# 
# The SQLite/Ruby Interface is free software; you can redistribute it and/or
# modify  it  under the terms of the GNU General Public License as published
# by  the  Free  Software  Foundation;  either  version 2 of the License, or
# (at your option) any later version.
# 
# The SQLite/Ruby Interface is distributed in the hope that it will be useful,
# but   WITHOUT   ANY   WARRANTY;  without  even  the  implied  warranty  of
# MERCHANTABILITY  or  FITNESS  FOR  A  PARTICULAR  PURPOSE.   See  the  GNU
# General Public License for more details.
# 
# You  should  have  received  a  copy  of  the  GNU  General Public License
# along with the SQLite/Ruby Interface;  if  not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
# --------------------------------------------------------------------------
# This demonstrates the use of the PRAGMA features provided by SQLite for
# querying and setting meta information about the database and tables.
#
# Author: Jamis Buck (jgb3@email.byu.edu)
# Date: June 2003
# --------------------------------------------------------------------------

require 'sqlite'

class PragmaDemo
  def initialize
    @db = SQLite::Database.new( "sample.db", 0 )
  end

  def start_test( prompt )
    puts
    print prompt + " (press enter to begin this text)"
    gets
  end

  def do_cache_size
    start_test "Cache size test:"
    puts "  size is now: #{@db.cache_size}"
    puts "  setting size to 100..."
    @db.cache_size = 100
    puts "  size is now: #{@db.cache_size}"
  end

  def do_database_list
    start_test "Database list test:"
    @db.database_list do |row|
      puts "  Row:"
      fields = ( @db.use_arrayfields? ? row.fields : row.keys )
      fields.each do |col|
        next if col.class != String
        puts "    #{col}: #{row[col]}"
      end
    end
  end

  def do_index_info
    start_test "Index info test:"
    @db.index_info( "idx_person_surname" ) do |row|
      puts "  Row:"
      fields = ( @db.use_arrayfields? ? row.fields : row.keys )
      fields.each do |col|
        next if col.class != String
        puts "    #{col}: #{row[col]}"
      end
    end
  end

  def do_index_list
    start_test "Index list test:"
    @db.index_list( "person" ) do |row|
      puts "  Row:"
      fields = ( @db.use_arrayfields? ? row.fields : row.keys )
      fields.each do |col|
        next if col.class != String
        puts "    #{col}: #{row[col]}"
      end
    end
  end

  def do_integrity_check
    start_test "Integrity check test:"
    begin
      @db.integrity_check
      puts "  Looks great!"
    rescue SQLite::DatabaseException => exc
      puts "  Problem: #{exc.message}"
    end
  end

  def do_table_info
    start_test "Table info test:"
    @db.table_info( "person" ) do |row|
      puts "  Row:"
      fields = ( @db.use_arrayfields? ? row.fields : row.keys )
      fields.each do |col|
        next if col.class != String
        puts "    #{col}: #{row[col]}"
      end
    end
  end

  def do_parser_trace
    start_test "Parser trace test:"
    @db.parser_trace="ON"
    @db.execute( "select a.surname, b.address from person a, email b where a.id = b.person_id" )
    @db.parser_trace="OFF"
  end

  def do_vdbe_trace
    start_test "VDBE trace test:"
    @db.vdbe_trace="ON"
    @db.execute( "select a.surname, b.address from person a, email b where a.id = b.person_id" )
    @db.vdbe_trace="OFF"
  end
end

demo = PragmaDemo.new
demo.do_cache_size
demo.do_database_list
demo.do_index_info
demo.do_index_list
demo.do_integrity_check
demo.do_table_info
demo.do_parser_trace
demo.do_vdbe_trace
