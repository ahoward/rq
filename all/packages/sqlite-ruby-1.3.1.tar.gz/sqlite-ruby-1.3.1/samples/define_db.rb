#!/usr/bin/ruby -Ilib

# --------------------------------------------------------------------------
# define_db.rb -- defines the sample database
# Copyright (C) 2003 Jamis Buck (jgb3@email.byu.edu)
# --------------------------------------------------------------------------
# This file is part of the SQLite ruby interface.
# 
# The SQLite/Ruby Interface is free software; you can redistribute it and/or
# modify  it  under the terms of the GNU General Public License as published
# by  the  Free  Software  Foundation;  either  version 2 of the License, or
# (at your option) any later version.
# 
# The SQLite/Ruby Interface is distributed in the hope that it will be useful,
# but   WITHOUT   ANY   WARRANTY;  without  even  the  implied  warranty  of
# MERCHANTABILITY  or  FITNESS  FOR  A  PARTICULAR  PURPOSE.   See  the  GNU
# General Public License for more details.
# 
# You  should  have  received  a  copy  of  the  GNU  General Public License
# along with the SQLite/Ruby Interface;  if  not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
# --------------------------------------------------------------------------
# This defines the sample database by reading the dbdef.sql script and
# executing the lines.
#
# Author: Jamis Buck (jgb3@email.byu.edu)
# Date: June 2003
# --------------------------------------------------------------------------

require 'sqlite'

class DefineDB
  def initialize
    @db = SQLite::Database.new( "sample.db", 0 )

    puts "SQLite version : #{SQLite::Database::VERSION}"
    puts "SQLite encoding: #{SQLite::Database::ENCODING}"
  end

  def execute_script( script )
    File.open( script, "r" ) do |file|
      query = ""
      file.readlines.each do |line|
        query << line
        if @db.complete? query
          @db.execute query
          query = ""
        end
      end
    end
  end
end

controller = DefineDB.new
controller.execute_script "samples/dbdef.sql"
