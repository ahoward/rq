create table person
(
  id INTEGER PRIMARY KEY,
  surname VARCHAR(30) NOT NULL,
  given_names VARCHAR(60),
  birth_date DATE
);

create index idx_person_surname on person ( surname );

create table email
(
  person_id INTEGER,
  address VARCHAR(40)
);

create index idx_email_person_id on email ( person_id );

insert into person values ( NULL, 'Washington', 'George', '1732-02-22' );
insert into person values ( NULL, 'Lincoln', 'Abraham', '1809-02-12' );

insert into person values ( NULL, 'Tong', 'Kim Chi', '1974-07-25' );
insert into email values ( last_insert_rowid(), 'kctong@yahoo.com' );

insert into person values ( NULL, 'Redington', 'Luther Porter', '1981-11-01' );
insert into email values ( last_insert_rowid(), 'lpred@msn.com' );

insert into person values ( NULL, 'Darcy', 'Fitzwilliam', '1963-04-27' );
insert into email values ( last_insert_rowid(), 'pandp@email.com' );

insert into person values ( NULL, 'Bennet', 'Elizabeth', '1978-05-04' );
insert into email values ( last_insert_rowid(), 'pemperly@ae.com' );

insert into person values ( NULL, 'Poppins', 'Mary', '1932-12-25' );
insert into email values ( last_insert_rowid(), 'nannies@magic.com' );
