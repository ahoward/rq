#!/usr/bin/ruby -Ilib

# --------------------------------------------------------------------------
# advanced.rb -- examples of the advanced features of SQLite
# Copyright (C) 2003 Jamis Buck (jgb3@email.byu.edu)
# --------------------------------------------------------------------------
# This file is part of the SQLite ruby interface.
# 
# The SQLite/Ruby Interface is free software; you can redistribute it and/or
# modify  it  under the terms of the GNU General Public License as published
# by  the  Free  Software  Foundation;  either  version 2 of the License, or
# (at your option) any later version.
# 
# The SQLite/Ruby Interface is distributed in the hope that it will be useful,
# but   WITHOUT   ANY   WARRANTY;  without  even  the  implied  warranty  of
# MERCHANTABILITY  or  FITNESS  FOR  A  PARTICULAR  PURPOSE.   See  the  GNU
# General Public License for more details.
# 
# You  should  have  received  a  copy  of  the  GNU  General Public License
# along with the SQLite/Ruby Interface;  if  not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
# --------------------------------------------------------------------------
# This demonstrates custom functions that can be used in queries, including
# custom aggregate functions.
#
# Author: Jamis Buck (jgb3@email.byu.edu)
# Date: June 2003
# --------------------------------------------------------------------------

require 'sqlite'

class AdvancedDemo
  def initialize
    @db = SQLite::Database.new( "sample.db", 0 )
  end

  def query_1
    # define a custom function
    count = 0
    @db.create_function( "row", 0, proc { count += 1; count }, nil )

    puts "Row Counter:"
    puts "  %5-s %20-s %20-s" % [ "Row", "Surname", "Given Names" ]

    @db.execute( "select row(), surname, given_names from person order by surname" ) do |row|
      puts "  %5-s %20-s %20-s" % [ row[0], row[1], row[2] ]
    end
    puts
  end

  def query_2
    @db.create_function( "scrunch", 2, proc { |ctx,a,b| ">>#{a}|#{b}<<" }, nil )

    puts "Scrunch Function:"
    puts "  %30-s" % [ "Scrunched Name" ]

    @db.execute( "select scrunch( surname, given_names ) from person order by surname" ) do |row|
      puts "  %30-s" % [ row[0] ]
    end
    puts
  end

  def query_3
    @db.create_aggregate(
      "count_greater_than",
      2,
      proc { |ctx,a,b|
        ctx.properties["count"] = 0 if !ctx.properties["count"]
        ctx.properties["count"] += 1 if a > b
      },
      proc { |ctx| ctx.properties["count"] },
      nil )

    puts "Custom Aggregate Function:"
    print "  count_greater_than(surname,'Lincoln'): "
    @db.execute( "select count_greater_than( surname, 'Lincoln' ) from person" ) { |row| puts row[0] }
    print "  count_greater_than(surname,'Bennet'): "
    @db.execute( "select count_greater_than( surname, 'Bennet' ) from person" ) { |row| puts row[0] }
    print "  count_greater_than(surname,'Washington'): "
    @db.execute( "select count_greater_than( surname, 'Washington' ) from person" ) { |row| puts row[0] }
    puts
  end
end

demo = AdvancedDemo.new
demo.query_1
demo.query_2
demo.query_3
