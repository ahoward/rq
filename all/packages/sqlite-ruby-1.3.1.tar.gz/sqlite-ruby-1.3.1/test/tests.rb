require 'fileutils'
require 'optparse'
require 'test/unit/testsuite'
require 'test/unit/ui/console/testrunner'

# ======================================================================
# UTILITY FUNCTIONS
# ======================================================================

def can_require_library( lib )
  begin
    require lib
    return true
  rescue Exception
    return false
  end
end

def open_db
  FileUtils.mkdir_p "#{$test_dir}/db"
  SQLite::Database.open( "#{$test_dir}/db/fixtures.db" )
end

# ======================================================================
# OPTIONAL PARAMETER PROCESSING
#
# Only process the parameters if we aren't running inside of an
# installing gem... we can detect this by checking to see if the Gem
# module has been defined. If it has, then we are in a gem that is
# currently being installed.
# ======================================================================

$use_gui = false

unless defined? Gem
  opts = OptionParser.new do |opts|
    opts.banner = "Usage: tests.rb [options]"
    opts.separator ""
    opts.separator "Options:"

    opts.on( "-g", "--[no-]use-gui", "Display test results using a GUI window, if available" ) do |v|
      $use_gui = v
    end

    opts.on_tail( "-h", "--help", "Show this message" ) do
      puts opts
      exit
    end
  end
  opts.parse!
end

# ======================================================================
# DETERMINE WHERE THE TEST FILES ARE RELATIVE TO WHERE THE SCRIPT IS
# BEING EXECUTED.
# ======================================================================

$test_dir = File.dirname( __FILE__ )
$:.unshift "#{$test_dir}/lib"

# ======================================================================
# MAKE SURE "LOCAL" COPY OF THE LIBRARIES ARE CURRENT, AND COPY/REBUILD
# THEM IF THEY ARE NOT.
# ======================================================================

FileUtils.mkdir_p "#{$test_dir}/lib"

unless FileUtils.uptodate?( "#{$test_dir}/lib/_sqlite.so", "#{$test_dir}/../ext/sqlite.c" )
  FileUtils.mkdir_p "#{$test_dir}/build"
  FileUtils.cp [ "#{$test_dir}/../ext/extconf.rb", "#{$test_dir}/../ext/sqlite.c" ], "#{$test_dir}/build"
  FileUtils.cd( "#{$test_dir}/build" ) do
    system "ruby extconf.rb >/dev/null" or fail( "could not configure sqlite/ruby module" )
    system "make >/dev/null" or fail( "could not build sqlite/ruby module" )
  end
  FileUtils.cp "#{$test_dir}/build/_sqlite.so", "#{$test_dir}/lib", :verbose=>true
  FileUtils.rm_rf "#{$test_dir}/build"
end

unless FileUtils.uptodate?( "#{$test_dir}/lib/sqlite.rb", "#{$test_dir}/../lib/sqlite.rb" )
  FileUtils.cp "#{$test_dir}/../lib/sqlite.rb", "#{$test_dir}/lib", :verbose=>true
end

# ======================================================================
# LOAD THE TEST CASES
# ======================================================================

require 'sqlite'

Dir["#{$test_dir}/test_*.rb"].each do |tests|
  require tests
end

# ======================================================================
# DETERMINE THE TESTRUNNER TO USE
# ======================================================================

test_runner = Test::Unit::UI::Console::TestRunner

if $use_gui
  if can_require_library( "test/unit/ui/gtk2/testrunner" )
    test_runner = Test::Unit::UI::GTK2::TestRunner
  elsif can_require_library( "test/unit/ui/gtk/testrunner" )
    test_runner = Test::Unit::UI::GTK::TestRunner
  elsif can_require_library( "test/unit/ui/fox/testrunner" )
    test_runner = Test::Unit::UI::Fox::TestRunner
  elsif can_require_library( "test/unit/ui/tk/testrunner" )
    test_runner = Test::Unit::UI::Tk::TestRunner
  end
end

# ======================================================================
# CREATE OUR TOP-LEVEL TEST SUITE
# ======================================================================

class TS_AllTests
  def self.suite
    suite = Test::Unit::TestSuite.new( "All SQLite/Ruby Unit Tests" )

    ObjectSpace.each_object( Class ) do |unit_test|
      next unless unit_test.name =~ /^T[CS]_/ && unit_test.superclass == Test::Unit::TestCase
      suite << unit_test.suite
    end

    return suite
  end
end

# ======================================================================
# INITIALIZE THE FIXTURES DATABASE
# ======================================================================

File.open( "#{$test_dir}/sql/fixtures.sql" ) do |file|
  FileUtils.rm_rf "#{$test_dir}/db"
  db = open_db
  db.execute file.read
  db.close
end

# ======================================================================
# RUN THE TEST CASES
# ======================================================================

test_runner.run( TS_AllTests )
