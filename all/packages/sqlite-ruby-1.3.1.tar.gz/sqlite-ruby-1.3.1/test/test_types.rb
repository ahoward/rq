require 'test/unit/testcase'
require 'sqlite'

class TC_TypeTranslation < Test::Unit::TestCase

  def setup
    @db = open_db

    @db.execute "delete from C"
    @db.execute <<-ESQL
      insert into C values (
        '1974-07-25',
        '1974-07-25 12:13:14',
        '12:13:14',
        3.14, 3.14, 3.14, 3.14, 3.14, 3.14, 3.14,
        30, 30, 30, 30, 30,
        1, 0, 1,
        1084337032,
        0,
        16,
        'hello', 'hello', 'hello', 'hello',
        'object',
        NULL, NULL, NULL
      )
    ESQL
  end

  def teardown
    @db.close
  end

  def test_show_datatypes
    @db.show_datatypes = true

    row = @db.get_first_row "select * from C"

    assert_equal "DATE", row.column_types[0]
    assert_equal "DATETIME", row.column_types[1]
    assert_equal "TIME", row.column_types[2]
    assert_equal "DECIMAL", row.column_types[3]
    assert_equal "FLOAT", row.column_types[4]
    assert_equal "NUMERIC", row.column_types[5]
    assert_equal "DOUBLE", row.column_types[6]
    assert_equal "REAL", row.column_types[7]
    assert_equal "DEC", row.column_types[8]
    assert_equal "FIXED", row.column_types[9]
    assert_equal "INTEGER", row.column_types[10]
    assert_equal "SMALLINT", row.column_types[11]
    assert_equal "MEDIUMINT", row.column_types[12]
    assert_equal "INT", row.column_types[13]
    assert_equal "BIGINT", row.column_types[14]
    assert_equal "BIT", row.column_types[15]
    assert_equal "BOOL", row.column_types[16]
    assert_equal "BOOLEAN", row.column_types[17]
    assert_equal "TIMESTAMP", row.column_types[18]
    assert_equal "TINYINT(1)", row.column_types[19]
    assert_equal "TINYINT(4)", row.column_types[20]
    assert_equal "STRING", row.column_types[21]
    assert_equal "VARCHAR(15)", row.column_types[22]
    assert_equal "CHAR(15)", row.column_types[23]
    assert_equal "VARCHAR2(15)", row.column_types[24]
    assert_equal "OBJECT", row.column_types[25]
    assert_equal "STRING", row.column_types[26]
    assert_equal "DATE", row.column_types[27]
    assert_equal "BOOLEAN", row.column_types[28]

    @db.show_datatypes = false
  end

  def test_translate_types
    @db.show_datatypes = true
    @db.type_translation = true

    row = @db.get_first_row "select * from C"

    t1 = Time.local( 1974, 7, 25 )
    t2 = Time.local( 1974, 7, 25, 12, 13, 14 )
    t3 = Time.now
    t3 = Time.local( t3.year, t3.mon, t3.day, 12, 13, 14 )
    t4 = Time.at( 1084337032 )

    assert_equal t1, row[0]
    assert_equal t2, row[1]
    assert_equal t3, row[2]

    assert_equal 3.14, row[3]
    assert_equal 3.14, row[4]
    assert_equal 3.14, row[5]
    assert_equal 3.14, row[6]
    assert_equal 3.14, row[7]
    assert_equal 3.14, row[8]
    assert_equal 3.14, row[9]

    assert_equal 30, row[10]
    assert_equal 30, row[11]
    assert_equal 30, row[12]
    assert_equal 30, row[13]
    assert_equal 30, row[14]

    assert_equal true, row[15]
    assert_equal false, row[16]
    assert_equal true, row[17]

    assert_equal t4, row[18]
    assert_equal false, row[19]
    assert_equal 16, row[20]

    assert_equal "hello", row[21]
    assert_equal "hello", row[22]
    assert_equal "hello", row[23]
    assert_equal "hello", row[24]

    assert_equal "object", row[25]

    assert_nil row[26]
    assert_nil row[27]
    assert_nil row[28]

    @db.type_translation = false
    @db.show_datatypes = false
  end

  def test_metadata_types
    @db.show_datatypes = true
    @db.type_translation = true

    rows = @db.database_list

    assert_equal "STRING", rows.first.column_types["seq"]
    assert_equal "STRING", rows.first.column_types["name"]
    assert_equal "STRING", rows.first.column_types["file"]

    @db.type_translation = false
    @db.show_datatypes = false
  end

end
