require 'test/unit/testcase'
require 'sqlite'

class TC_Serialize < Test::Unit::TestCase

  class Tester
    attr_reader :a
    attr_reader :b
    attr_reader :c

    def initialize( a, b, c )
      @a, @b, @c = a, b, c
    end

    def ==( t2 )
      @a == t2.a &&
      @b == t2.b &&
      @c == t2.c
    end
  end

  def setup
    @db = open_db

    @tester = Tester.new( 5, "hello", 1_230_491_204_371_203_471_249_871_234 )
    encoded = SQLite::Database.encode( @tester )

    @db.execute "delete from E"
    @db.execute <<-ESQL
      insert into E values ( 'tester', '#{encoded}' )
    ESQL
  end

  def teardown
    @db.close
  end

  def test_unserialize
    row = @db.get_first_row( "select * from E" )
    assert_equal( "tester", row['name'] )
    t = SQLite::Database.decode( row['thing'] )
    assert_equal( @tester, t )
  end

end
