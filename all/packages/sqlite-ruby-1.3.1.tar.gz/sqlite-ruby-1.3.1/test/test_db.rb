require 'test/unit/testcase'
require 'sqlite'

class TC_Database < Test::Unit::TestCase

  def setup
    @db = open_db
  end

  def teardown
    @db.close
  end

  def load_table_A
    @db.execute "delete from A"
    @db.execute "insert into A values ( 'a', 1, '2004-05-11' )"
    @db.execute "insert into A values ( 'b', 2, '2004-05-12' )"
    @db.execute "insert into A values ( 'c', 3, '2004-05-13' )"
    @db.execute "insert into A values ( 'b', 4, '2004-05-14' )"
    @db.execute "insert into A values ( 'd', 5, '2004-05-14' )"
    @db.execute "insert into A values ( 'e', 2, '2004-05-15' )"
  end

  def test_execute_statement
    @db.execute "delete from A"
    @db.execute "insert into A values ( 'Jamis', 30, '1974-07-25' )"
    assert_equal 1, @db.changes
    @db.execute "insert into A values ( 'Someone Else', 30, '1974-01-15' )"
    assert_equal 1, @db.changes
    @db.execute "update A set name = 'test' where age = 30"
    assert_equal 2, @db.changes

    # as per SQLite ticket #38, doing a "delete from A" (without a where clause)
    # does not set the changes property. Thus, we provide a trivial where clause so
    # that the changes property gets set.
    @db.execute "delete from A where 1"
    assert_equal 2, @db.changes
  end

  def test_execute_query
    load_table_A

    count = 0
    @db.execute( "select * from A" ) { |row| count += 1 }
    assert_equal 6, count

    rows = @db.execute( "select * from A where age = 2" )
    assert_equal 2, rows.size

    count = 0
    @db.execute( "select * from A" ) { |row| count += 1; SQLite::ABORT }
    assert_equal 1, count
  end

  def test_singleton_queries
    load_table_A

    row = @db.get_first_row( "select * from A where age = 1" )
    assert_equal [ "a", "1", "2004-05-11" ], [ row["name"], row["age"], row["birth"] ]

    date = @db.get_first_value( "select birth from A where age = 4" )
    assert_equal "2004-05-14", date
  end

  def test_comlete
    sql = "select * from"
    assert_equal false, @db.complete?( sql )
    sql << " A"
    assert_equal true, @db.complete?( sql + ";" )
    sql << " where"
    assert_equal false, @db.complete?( sql )
    sql << " 1"
    assert_equal true, @db.complete?( sql + ";" )
  end

  def test_interrupt
    load_table_A
    sql = "select a.* from A a, A b, A c, A d, A e, A f"
    running = false
    t = Thread.new do
      running = true
      assert_raises( SQLite::InterruptException ) do
        @db.execute( sql )
      end
      running = false
    end
    sleep 0.1
    assert_equal true, running
    sleep 0.1
    @db.interrupt
    t.join
    assert_equal false, running
  end

  def test_last_insert_rowid
    @db.execute "delete from B"
    @db.execute "insert into B values ( 1, 'hello' )"
    assert_equal 1, @db.last_insert_rowid
    @db.execute "insert into B values ( 22, 'hello again' )"
    assert_equal 22, @db.last_insert_rowid
  end

  def test_nil
    @db.execute "delete from A"
    @db.execute "insert into A values ( NULL, NULL, NULL )"
    @db.execute( "select * from A" ) do |row|
      assert_nil row["name"]
      assert_nil row["age"]
      assert_nil row["birth"]
    end
  end

  def test_quote
    q = "hello"
    assert_equal( q, SQLite::Database.quote( q ) )
    q = "O'Reilly"
    assert_equal( "O''Reilly", SQLite::Database.quote( q ) )
    q = "blah'blah'blah"
    assert_equal( "blah''blah''blah", SQLite::Database.quote( q ) )
    q = "''and''"
    assert_equal( "''''and''''", SQLite::Database.quote( q ) )
  end

  def test_encode_decode
    s = { :one=>"two", "three"=>:four, 5=>6 }
    assert_equal( s, SQLite::Database.decode( SQLite::Database.encode( s ) ) )
  end

  def test_lib_version
    version = SQLite::LIB_VERSION
    assert_instance_of Array, version
    assert_equal 3, version.length
    version.each { |e| assert_instance_of Fixnum, e }
  end

end
