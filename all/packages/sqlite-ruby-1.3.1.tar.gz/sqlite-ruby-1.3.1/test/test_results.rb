require 'test/unit/testcase'
require 'sqlite'

class TC_ResultSets < Test::Unit::TestCase

  def setup
    @db = open_db

    @db.execute "delete from A"
    @db.execute <<-ESQL
      insert into A values ( 'bob', 1, '2004-05-12' );
    ESQL
  end

  def teardown
    @db.close
  end

  def test_default_result_type
    assert_equal( false, @db.use_array? )
  end

  def test_hash_results
    @db.use_array = false
    results = @db.execute( "select * from A" )
    assert_instance_of( Hash, results[0] )
    assert_equal( "bob", results[0][0] )
    assert_equal( "bob", results[0]["name"] )
  end

  def test_array_results
    @db.use_array = true
    results = @db.execute( "select * from A" )
    assert_instance_of( Array, results[0] )
    assert_equal( "bob", results[0][0] )
    assert_equal( "name", results[0].fields[0] )
  end

end
