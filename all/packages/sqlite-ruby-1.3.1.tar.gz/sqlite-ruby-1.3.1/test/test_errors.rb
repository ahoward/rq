require 'test/unit/testcase'
require 'sqlite'
require 'thread'

class TC_Errors < Test::Unit::TestCase

  def setup
    @db = open_db

    @db.execute "delete from A"
    @db.execute <<-ESQL
      insert into A values ( 'bob', 1, '2004-05-12' );
      insert into A values ( 'joe', 2, '2004-07-03' );
    ESQL
  end

  def teardown
    @db.close
  end

  def test_locked
    mutex = Mutex.new
    resource = ConditionVariable.new

    t = Thread.new do
      @db.execute( "select * from A" ) { |row| mutex.synchronize { resource.wait(mutex) }; SQLite::ABORT }
    end

    sleep 0.1
    mutex.synchronize do
      begin
        assert_raise( SQLite::LockedException ) do
          @db.execute( "insert into A values ( 'jim', 3, '2004-07-03' )" )
        end
      ensure
        resource.signal
      end
    end
  end

  def test_busy
    db2 = open_db

    mutex = Mutex.new
    resource = ConditionVariable.new

    t = Thread.new do
      @db.execute( "select * from A" ) { |row| mutex.synchronize { resource.wait(mutex) }; SQLite::ABORT }
    end

    sleep 0.1
    mutex.synchronize do
      begin
        assert_raise( SQLite::BusyException ) do
          db2.execute( "insert into A values ( 'jim', 3, '2004-07-03' )" )
        end
      ensure
        resource.signal
        db2.close
      end
    end
  end

  def test_sql
    assert_raise( SQLite::SQLException ) do
      @db.execute( "select a big-ol thing from something over here" )
    end
  end

end
