require 'test/unit/testcase'
require 'sqlite'

class TC_Pragmas < Test::Unit::TestCase

  def setup
    @db = open_db
  end

  def teardown
    @db.close
  end

  def test_cache_size
    old_size = @db.cache_size

    @db.cache_size = 100
    assert_equal 100, @db.cache_size

    @db.cache_size = old_size
    assert_equal old_size, @db.cache_size
  end

  def test_default_cache_size
    old_size = @db.default_cache_size

    @db.default_cache_size = 100
    assert_equal 100, @db.default_cache_size

    @db.default_cache_size = old_size
    assert_equal old_size, @db.default_cache_size
  end

  def test_default_synchronous
    old_val = @db.default_synchronous

    @db.default_synchronous = "FULL"
    assert_equal "2", @db.default_synchronous

    @db.default_synchronous = "NORMAL"
    assert_equal "1", @db.default_synchronous

    @db.default_synchronous = "OFF"
    assert_equal "0", @db.default_synchronous

    @db.default_synchronous = old_val
    assert_equal old_val, @db.default_synchronous
  end

  def test_synchronous
    old_val = @db.synchronous

    @db.synchronous = "FULL"
    assert_equal "2", @db.synchronous

    @db.synchronous = "NORMAL"
    assert_equal "1", @db.synchronous

    @db.synchronous = "OFF"
    assert_equal "0", @db.synchronous

    @db.synchronous = old_val
    assert_equal old_val, @db.synchronous
  end

#  Can't test default_temp_store since SQLite complains that the temp store already
#  exists and can't be changed...
#
#  def test_default_temp_store
#    old_val = @db.default_temp_store

#    @db.default_temp_store = "DEFAULT"
#    assert_equal "0", @db.default_temp_store

#    @db.default_temp_store = "MEMORY"
#    assert_equal "2", @db.default_temp_store

#    @db.default_temp_store = "FILE"
#    assert_equal "1", @db.default_temp_store

#    @db.default_temp_store = old_val
#    assert_equal old_val, @db.default_temp_store
#  end

#  Can't test temp_store since SQLite complains that the temp store already
#  exists and can't be changed...
#
#  def test_temp_store
#    old_val = @db.temp_store

#    @db.temp_store = "DEFAULT"
#    assert_equal "0", @db.temp_store

#    @db.temp_store = "MEMORY"
#    assert_equal "2", @db.temp_store

#    @db.temp_store = "FILE"
#    assert_equal "1", @db.temp_store

#    @db.temp_store = old_val
#    assert_equal old_val, @db.temp_store
#  end

  def self.create_boolean_pragma_test_case( pragma )
    class_eval <<-EOFCASE
      def test_#{pragma}
        old_val = @db.#{pragma}

        @db.#{pragma} = true
        assert_equal true, @db.#{pragma}

        @db.#{pragma} = false
        assert_equal false, @db.#{pragma}

        @db.#{pragma} = old_val
        assert_equal old_val, @db.#{pragma}
      end
    EOFCASE
  end

  create_boolean_pragma_test_case "empty_result_callbacks"
  create_boolean_pragma_test_case "full_column_names"
  create_boolean_pragma_test_case "show_datatypes"
  create_boolean_pragma_test_case "vdbe_trace"

  def test_database_list
    rows = @db.database_list

    assert_equal "0", rows[0]["seq"]
    assert_equal "main", rows[0]["name"]
    assert_match %r{fixtures.db$}, rows[0]["file"]

    assert_equal "1", rows[1]["seq"]
    assert_equal "temp", rows[1]["name"]
    assert_nil rows[1]["file"]
  end

  def test_foreign_key_list
    rows = @db.foreign_key_list( "D" )

    assert_equal "b_id", rows.first["from"]
    assert_equal "id", rows.first["to"]
    assert_equal "0", rows.first["id"]
    assert_equal "B", rows.first["table"]
    assert_equal "0", rows.first["seq"]
  end

  def test_index_info
    rows = @db.index_info( "B_idx" )

    assert_equal "name", rows.first["name"]
    assert_equal "0", rows.first["seqno"]
    assert_equal "1", rows.first["cid"]
  end

  def test_index_list
    rows = @db.index_list( "B" )

    assert_equal "B_idx", rows.first["name"]
    assert_equal "0", rows.first["seq"]
    assert_equal "0", rows.first["unique"]
  end

  def test_table_info
    rows = @db.table_info( "B" )

    assert_equal "id", rows[0]["name"]
    assert_equal "INTEGER", rows[0]["type"]
    assert_equal "1", rows[0]["pk"]
    assert_equal "0", rows[0]["notnull"]
    assert_equal "0", rows[0]["cid"]
    assert_nil rows[0]["dflt_value"]

    assert_equal "name", rows[1]["name"]
    assert_equal "VARCHAR(60)", rows[1]["type"]
    assert_equal "0", rows[1]["pk"]
    assert_equal "0", rows[1]["notnull"]
    assert_equal "1", rows[1]["cid"]
    assert_nil rows[1]["dflt_value"]
  end
end
