require 'test/unit/testcase'
require 'sqlite'

begin

  require 'arrayfields'

  class TC_ArrayFields < Test::Unit::TestCase

    def setup
      @db = open_db
      @db.use_array = true
      @db.show_datatypes = true
      @db.type_translation = true

      @db.execute "delete from A"
      @db.execute <<-ESQL
        insert into A values ( 'bob', 1, '2004-05-12' );
      ESQL
    end

    def teardown
      @db.close
    end

    def test_fields
      row = @db.get_first_row "select * from A"
      assert_equal( [ "name", "age", "birth" ], row.fields )
    end

    def test_name_access
      row = @db.get_first_row "select * from A"
      assert_equal( "bob", row["name"] )
      assert_equal( 1, row["age"] )
      assert_equal( Time.mktime( 2004, 5, 12 ), row["birth"] )
    end

    def test_index_access
      row = @db.get_first_row "select * from A"
      assert_equal( "bob", row[0] )
      assert_equal( 1, row[1] )
      assert_equal( Time.mktime( 2004, 5, 12 ), row[2] )
    end

  end

rescue LoadError => e
  puts "'arrayfields' does not appear to exist... skipping arrayfields integration test"
end
