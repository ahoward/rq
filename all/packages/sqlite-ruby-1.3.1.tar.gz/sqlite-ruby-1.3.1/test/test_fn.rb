require 'test/unit/testcase'
require 'sqlite'

class TC_Functions < Test::Unit::TestCase

  def setup
    @db = open_db

    @db.execute "delete from A"
    @db.execute <<-ESQL
      insert into A values ( 'bob', 1, '2004-05-12' );
      insert into A values ( 'jim', 2, '2004-05-12' );
      insert into A values ( 'fred', 3, '2004-05-12' );
      insert into A values ( 'kim', 4, '2004-05-12' );
      insert into A values ( 'george', 5, '2004-05-12' );
      insert into A values ( 'mike', 6, '2004-05-12' );
      insert into A values ( 'phil', 7, '2004-05-12' );
      insert into A values ( 'tom', 8, '2004-05-12' );
      insert into A values ( 'pip', 9, '2004-05-12' );
      insert into A values ( 'nate', 10, '2004-05-12' );
    ESQL
  end

  def teardown
    @db.close
  end

  def test_function
    @db.create_function( "twice", 1, proc { |ctx,a| a.to_i*2 }, nil )

    value = @db.get_first_value( "select twice(age) from A where name='tom'" )
    assert_equal "16", value

    @db.create_function( "strmul", 2, proc { |ctx,a,b| a*b.to_i }, nil )

    value = @db.get_first_value( "select strmul(name,age) from A where name='fred'" )
    assert_equal "fredfredfred", value
  end

  def test_aggregate_function
    @db.create_aggregate(
      "count_longer_than",
      2,
      proc { |ctx,a,b|
        ctx.properties[ "count" ] ||= 0
        ctx.properties[ "count" ] += 1 if a.length > b.to_i
      },
      proc { |ctx| ctx.properties["count"] },
      nil )

    value = @db.get_first_value( "select count_longer_than(name,3) from A" )
    assert_equal "5", value

    value = @db.get_first_value( "select count_longer_than(name,4) from A" )
    assert_equal "1", value
  end

end
